import pyodbc
from typing import List
import pandas as pd
import os
import time

class DBConnectionNotEstablished(Exception):
    def __init__(self, database_path: str, timeout_s: float) -> None:
        self.message = f'Unable to connect to database at {database_path} in {timeout_s} seconds'
        super().__init__(self.message)

class AccessDBManipulator():
    def __init__(self, access_db_file_path: str, password: str, db_connection_attempts: int=5, db_retry_sleep_s: float=0.5):
        try:
            abs_access_db_file_path = os.path.abspath(access_db_file_path)

            if not os.path.exists(abs_access_db_file_path):
                raise FileNotFoundError(f'Unable to find file at {abs_access_db_file_path}')

            drivers = [item for item in pyodbc.drivers() if 'Microsoft Access Driver' in item]
            driver = drivers[-1]
            conn_string = f'DRIVER={driver};PWD={password};DBQ={abs_access_db_file_path};'
            self.conn = pyodbc.connect(conn_string)
            db_connection_attempt_idx = 0
            self.is_connection_valid = False
            while ((db_connection_attempt_idx < db_connection_attempts) and self.is_connection_valid == False):
                try:
                    # Attempt to get a valid cursor
                    try:
                        cur = self.conn.cursor()
                        is_connection_valid = True
                        print('Connection to access db was established!')
                        return
                    except:
                        raise
                except Exception as e:
                    is_connection_valid = False
                    print(f'Connection to access db was not established. Retrying in {db_retry_sleep_s} seconds...')
                    time.sleep(db_retry_sleep_s)
            if not self.is_connection_valid:
                raise DBConnectionNotEstablished(abs_access_db_file_path, db_retry_sleep_s * (db_connection_attempt_idx+1))

            
            # print(self.conn.tables())
            # print(tables)
            # print('Table count: ', len(tables))
        except:
            raise

    def close_db_connection(self):
        if self.is_connection_valid:
            self.conn.close()

    def get_table_names(self) -> List[str]:
        table_names = [t.table_name for t in self.conn.cursor().tables() if not ('MSys' in t.table_name)]
        return table_names

    def execute_query(self, query_string: str):
        start_time = time.time()
        cur = self.conn.cursor()
        cur.execute(query_string)
        columns = [c[0] for c in cur.description]
        data = []
        while True:
            row = cur.fetchone()
            if row is None:
                break
            data.append(list(row))
        cur.close()
        df = pd.DataFrame(data, columns=columns)
        end_time = time.time()
        # print(f'Query took {(end_time - start_time) * 1e3:.4f} ms to complete')
        return df
