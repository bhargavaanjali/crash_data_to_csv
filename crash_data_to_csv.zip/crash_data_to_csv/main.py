from crash_db_package import AccessDBManipulator
import sys
import pandas as pd
import time

ACCESS_DB_FILE_PATH = 'crash.accdb'
OUTPUT_CSV_FILE_PATH = 'indcr.csv'
PASSWORD = 'Outdared-Aventres221'

def main():
    try:
        adb = AccessDBManipulator(ACCESS_DB_FILE_PATH, PASSWORD)

        print('\nTable Names:\n* ' + '\n* '.join(adb.get_table_names()), '\n')

        constrain_n_records = False
        n_records = 100
        print(f'Using constrain_n_records: {constrain_n_records} & n_records: {n_records}')

        selection_qualifier = ('', f'top {n_records}')[constrain_n_records]

        #Operations for indcr table

        vtind = f'select {selection_qualifier} * from VTIndicator order by DocumentNumber'
        df_vtind = adb.execute_query(vtind)
        crash = f'select {selection_qualifier} * from Crash order by DocumentNumber'
        df_crash = adb.execute_query(crash)

        start_time = time.time()
        df_indcr = pd.merge(df_vtind, df_crash, on="DocumentNumber", how="outer")
        end_time = time.time()
        print(f'Join took {(end_time - start_time) * 1e3:.4f} ms to complete')

        start_time = time.time()
        df_indcr.to_csv(OUTPUT_CSV_FILE_PATH)
        end_time = time.time()
        print(f'CSV conversion took {(end_time - start_time) * 1e3:.4f} ms to complete')

        

        # Operations for vehdr table
        OUTPUT_CSV_FILE_PATH1 = 'vehdr.csv'

        vehicle = f'select {selection_qualifier}  * from Vehicle order by VehicleId'
        # query =  'SELECT VTIndicator.*, Crash.* FROM VTIndicator INNER JOIN Crash ON CStr(Crash.DocumentNumber) = CStr(VTIndicator.DocumentNumber)'
        df_vehicle = adb.execute_query(vehicle)
        driver = f'select {selection_qualifier} * from Driver order by VehicleId'
        df_driver = adb.execute_query(driver)

        start_time = time.time()
        df_vehdr = pd.merge(df_vehicle, df_driver, on="VehicleId", how="inner")
        df_vehdr.drop(columns=['DocumentNumber_y'])
        df_vehdr = df_vehdr.rename(columns={'DocumentNumber_x': 'DocumentNumber'})
        end_time = time.time()
        print(f'Join took {(end_time - start_time) * 1e3:.4f} ms to complete')

        start_time = time.time()
        df_vehdr.to_csv(OUTPUT_CSV_FILE_PATH1)
        end_time = time.time()
        print(f'CSV conversion took {(end_time - start_time) * 1e3:.4f} ms to complete')


        # Operations to join indcr and vehdr table

        OUTPUT_CSV_FILE_PATH2 = 'vehindcr.csv'

        start_time = time.time()
        df_vehindcr = pd.merge(df_indcr, df_vehdr, on="DocumentNumber", how="outer")
        end_time = time.time()
        print(f'Join took {(end_time - start_time) * 1e3:.4f} ms to complete')

        start_time = time.time()
        df_vehindcr.to_csv(OUTPUT_CSV_FILE_PATH2)
        end_time = time.time()
        print(f'CSV conversion took {(end_time - start_time) * 1e3:.4f} ms to complete')

        adb.close_db_connection()  # Adding this manually because we can't close the connection if we get exceptions

    except KeyboardInterrupt as e:
        print('Exiting program cleanly')
        sys.exit()

if __name__ == '__main__':
    main()